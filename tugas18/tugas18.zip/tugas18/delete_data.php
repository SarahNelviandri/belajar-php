<?php
include('koneksi.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $queryDelete = "DELETE FROM products WHERE id = '$id'";

    // Eksekusi query
    if ($conn->query($queryDelete) === TRUE) {
        echo '<script>alert("Data berhasil dihapus.");</script>';
        echo "<script>window.location.href = 'index.php';</script>";
    } else {
        echo "Error: " . $queryDelete . "<br>" . $conn->error;
    }

    // Tutup koneksi database
    $conn->close();
} else {
    echo "ID produk tidak ditemukan.";
}
?>
