<?php

include('koneksi.php');

class ProductDeleter {
    private $conn;
  
    public function __construct($conn) {
        $this->conn = $conn;
    }
  
    public function deleteProduct($productId) {
        $query = "DELETE FROM products WHERE id = ?";
        $statement = $this->conn->prepare($query);

        if (!$statement) {
            echo "Error in preparing the query: " . $this->conn->error;
            return false;
        }

        $statement->bind_param('i', $productId);

        try {
            if ($statement->execute()) {
                return true;
            } else {
                echo "Error in executing the query: " . $this->conn->error;
                return false;
            }
        } catch (Exception $e) {
            echo "Error: " . $e->getMessage();
            return false;
        }
    }
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $productDeleter = new ProductDeleter($conn);

    if ($productDeleter->deleteProduct($id)) {
        echo '<script>alert("Data berhasil dihapus.");</script>';
        echo "<script>window.location.href = 'product.php'; </script>";
    } else {
        echo '<script>alert("Terjadi kesalahan saat menghapus data");</script>';
        echo "<script>window.location.href = 'product.php'; </script>";
    }

} else {
    echo "ID produk tidak ditemukan.";
}

$conn = null;
?>
